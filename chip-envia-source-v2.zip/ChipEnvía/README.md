# Chip Envía — Android nativa (base funcional en desarrollo)

App Android Kotlin + Jetpack Compose, `minSdk 26` (Android 8.0), `targetSdk 35`. No contiene una APK precompilada ni afirma haberse probado en dispositivos.

## Funciones en esta compilación

- Perfil local con nombre, foto, ID generado y fecha de nacimiento opcional almacenados en el teléfono.
- Carnet QR con nombre e ID; la fecha de nacimiento y la foto no se codifican ni se envían con el QR.
- Salas cercanas por código o QR con Google Play services Nearby Connections (`P2P_CLUSTER`). La app anuncia y busca la sala. Las solicitudes de conexión requieren aprobación manual en cada extremo.
- Mensajes de texto en el clúster con retransmisión limitada por TTL y deduplicación por ID.
- Envío de imágenes a los pares conectados directamente; la foto recibida se muestra como imagen real al finalizar la transferencia.
- Tres en raya con X/O asignados por crear/unirse y restricción básica de turno. Está pensado como juego entre dos teléfonos y no tiene autoridad de servidor.
- Pantalla informativa de privacidad y límites. Servicio visible de primer plano mientras la sesión de Nearby se encuentra activa, más notificación local de mensajes si Android permite mostrarlas.

## Límites y privacidad

Las conexiones son de corto alcance y dependen de Nearby Connections y Google Play services instalados/disponibles en el teléfono. El sistema puede detener la actividad o las conexiones por ahorro de energía/fabricante. El servicio de primer plano ayuda a mantener la sesión en segundo plano y muestra una notificación persistente, pero **no garantiza** recepción o entrega si la app es cerrada a la fuerza, el dispositivo pierde alcance, Android detiene el servicio, o la app no tiene los permisos/Google Play services requeridos. Un teléfono apagado no recibe mensajes. No hay servidor remoto ni notificaciones push. No se afirma cifrado propio ni seguridad de extremo a extremo; los usuarios deben aceptar solicitudes solo de personas conocidas. Mensajes de texto/juego se retransmiten por el clúster; las fotos se mandan solo a los pares conectados directamente y no se retransmiten.

El perfil se guarda en preferencias locales de la app. La fecha de nacimiento no forma parte del QR ni del paquete de chat. No se solicitan documentos. La app no sincroniza estos datos a un servicio externo.

## Compilación automática

El workflow `.github/workflows/android.yml` compila `assembleDebug` con Java 17 y Gradle 8.11.1 en GitHub Actions. El APK se conserva como artifact de Actions del repositorio privado por 30 días. Es una APK instalable de depuración firmada con la llave debug efímera/estándar de la ejecución; no es un lanzamiento de producción y una futura actualización firmada con otra llave requerirá desinstalar esta versión o conservar la llave de publicación. No se incorporan contraseñas ni llaves privadas.

Para compilar en Android Studio se requiere Android SDK 35, JDK 17 y Gradle 8.11.1 o el wrapper generado por Actions. Abre esta carpeta, sincroniza Gradle y compila `app:assembleDebug`. Prueba la app en dos o más Android cercanos con Google Play services; concede los permisos de dispositivos cercanos antes de crear o unirte a una sala.
