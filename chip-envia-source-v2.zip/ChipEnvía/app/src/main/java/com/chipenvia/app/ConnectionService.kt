package com.chipenvia.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Keeps the nearby connection session visible to Android while the user backgrounds the app. */
class ConnectionService : Service() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Chip Envía · conexión cercana")
            .setContentText("La sesión cercana está activa")
            .setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(SESSION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(SESSION_ID, n)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }

    companion object {
        const val CHANNEL = "chip_nearby"
        private const val SESSION_ID = 7101
        fun start(context: Context) {
            val i = Intent(context, ConnectionService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) { context.stopService(Intent(context, ConnectionService::class.java)) }
        fun notifyMessage(context: Context, sender: String, body: String) {
            ensureChannel(context)
            val n = NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("Mensaje de $sender").setContentText(body.take(120))
                .setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_MESSAGE).build()
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        }
        private fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.createNotificationChannel(NotificationChannel(CHANNEL, "Conexión y mensajes cercanos", NotificationManager.IMPORTANCE_DEFAULT))
            }
        }
    }
}
