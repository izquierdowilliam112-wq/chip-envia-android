package com.chipenvia.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

private val Ink = Color(0xFF20213A)
private val Purple = Color(0xFF6C5CE7)
private val Lilac = Color(0xFFF0EEFF)
private val Muted = Color(0xFF777991)

class MainActivity : ComponentActivity() {
    private lateinit var nearby: NearbyChat
    private var pendingNearbyAction: (() -> Unit)? = null
    private val requiredPermissions: Array<String> get() = buildList {
        if (Build.VERSION.SDK_INT >= 31) {
            add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS) }
    }.toTypedArray()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }.values.all { it }) pendingNearbyAction?.invoke()
        pendingNearbyAction = null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nearby = NearbyChat(this)
        setContent { ChipApp(nearby, ::requestNearbyPermissions) }
    }
    private fun requestNearbyPermissions(action: () -> Unit) {
        val missing = requiredPermissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) action() else { pendingNearbyAction = action; permissionLauncher.launch(missing.toTypedArray()) }
    }
}

data class ChatLine(val sender: String, val text: String, val mine: Boolean, val imageUri: String? = null)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChipApp(nearby: NearbyChat, askPermissions: (() -> Unit) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("chip_profile", 0) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var birthday by remember { mutableStateOf(prefs.getString("birthday", "") ?: "") }
    var publicId by remember { mutableStateOf(prefs.getString("id", "") ?: "") }
    var profilePhoto by remember { mutableStateOf(prefs.getString("photo", "") ?: "") }
    val incomingUri = (ctx as? android.app.Activity)?.intent?.data
    val incomingKind = incomingUri?.host
    val incomingCode = if (incomingKind == "sala") incomingUri.pathSegments.lastOrNull().orEmpty() else ""
    val incomingProfileId = if (incomingKind == "perfil") incomingUri.pathSegments.lastOrNull().orEmpty() else ""
    val incomingProfileName = incomingUri?.getQueryParameter("nombre").orEmpty()
    var screen by remember { mutableStateOf(if (name.isBlank()) "profile" else if (incomingKind == "perfil") "sharedCard" else "home") }
    var showPrivacy by remember { mutableStateOf(false) }
    var roomCode by remember { mutableStateOf("") }
    var joinCode by remember { mutableStateOf(incomingCode) }
    var draft by remember { mutableStateOf("") }
    var currentTab by remember { mutableStateOf(if (incomingKind == "sala") "Sala" else "Chat") }
    var ticTurn by remember { mutableStateOf("X") }
    var tic by remember { mutableStateOf(List(9) { "" }) }
    val scope = rememberCoroutineScope()
    val lines by nearby.messages.collectAsState()
    val remoteGame by nearby.gameBoard.collectAsState()
    val gamePlayer by nearby.gamePlayer.collectAsState()
    val peers by nearby.peers.collectAsState()
    val pending by nearby.pending.collectAsState()
    val activeRoom by nearby.room.collectAsState()
    val snack = remember { SnackbarHostState() }

    val profilePicker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching {
            val f = File(ctx.filesDir, "profile_${System.currentTimeMillis()}.img")
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { output -> input.copyTo(output) } }
            profilePhoto = android.net.Uri.fromFile(f).toString(); prefs.edit().putString("photo", profilePhoto).apply()
        }.onFailure { scope.launch { snack.showSnackbar("No se pudo guardar la foto") } }
    }
    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runCatching {
            val f = File(ctx.cacheDir, "chip_${System.currentTimeMillis()}.jpg")
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { output -> input.copyTo(output) } }
            nearby.sendPhoto(f, name)
        }.onFailure { scope.launch { snack.showSnackbar("No se pudo preparar la foto") } }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Color(0xFFF7F7FC), surface = Color.White)) {
        Scaffold(snackbarHost = { SnackbarHost(snack) }, containerColor = Color(0xFFF7F7FC)) { padding ->
            if (showPrivacy) {
                Column(Modifier.fillMaxSize().padding(padding).padding(22.dp)) {
                    TopBar("Privacidad y límites") { showPrivacy = false }
                    Spacer(Modifier.height(18.dp))
                    Text("Qué se guarda", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Tu nombre, fecha de nacimiento opcional, ID y foto de perfil se guardan localmente en este teléfono. La fecha no se incluye en el QR ni se envía a otras personas.", color = Muted)
                    Spacer(Modifier.height(16.dp)); Text("Conexiones cercanas", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Chip Envía usa Google Play services Nearby Connections entre teléfonos próximos. No hay servidor de mensajes ni cifrado propio prometido. Cada solicitud necesita aceptación manual. El alcance y el trabajo en segundo plano dependen de Android, Google Play services y el fabricante; un teléfono apagado no recibe mensajes.", color = Muted)
                    Spacer(Modifier.height(16.dp)); Text("Fotos", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Las fotos solo se comparten cuando eliges enviarlas.", color = Muted)
                }
            } else when (screen) {
                "profile" -> ProfileScreen(name, { name = it }, birthday, { birthday = it }, profilePhoto,
                    { profilePicker.launch("image/*") }, {
                        if (name.isBlank()) scope.launch { snack.showSnackbar("Escribe tu nombre para crear el perfil") }
                        else {
                            if (publicId.isBlank()) publicId = UUID.randomUUID().toString().take(8).uppercase()
                            prefs.edit().putString("name", name.trim()).putString("birthday", birthday).putString("id", publicId).putString("photo", profilePhoto).apply(); screen = "home"
                        }
                    }, padding)
                "sharedCard" -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                    TopBar("Carnet compartido") { screen = "home" }
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Person, null, tint = Purple, modifier = Modifier.size(52.dp))
                            Text(incomingProfileName.ifBlank { "Usuario de Chip Envía" }, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("ID $incomingProfileId", color = Muted)
                            Text("El QR contiene nombre e ID; no fecha de nacimiento ni foto.", color = Muted)
                        }
                    }
                }
                "card" -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                    TopBar("Mi carnet") { screen = "home" }
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (profilePhoto.isNotBlank()) Image(rememberAsyncImagePainter(profilePhoto), "Foto de perfil", Modifier.size(70.dp).background(Lilac, CircleShape)) else Icon(Icons.Default.Person, null, tint = Purple, modifier = Modifier.size(60.dp))
                            Text(name, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink); Text("ID $publicId", color = Muted)
                            Spacer(Modifier.height(16.dp)); QrImage("chipenvia://perfil/$publicId?nombre=${java.net.URLEncoder.encode(name, "UTF-8")}", Modifier.size(210.dp))
                            Text("Tu fecha de nacimiento no se comparte", color = Purple, fontSize = 12.sp)
                        }
                    }
                }
                else -> Column(Modifier.fillMaxSize().padding(padding)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Chip Envía", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink); Text("Hola, $name 👋", color = Muted) }
                        IconButton(onClick = { showPrivacy = true }) { Icon(Icons.Default.PrivacyTip, "Privacidad", tint = Purple) }
                        IconButton(onClick = { screen = "card" }) { Icon(Icons.Default.QrCode2, "Mi carnet", tint = Purple) }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Chat", "Sala", "Juegos").forEach { tab -> FilterChip(selected = currentTab == tab, onClick = { currentTab = tab }, label = { Text(tab) }) }
                    }
                    when (currentTab) {
                        "Chat" -> Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(if (activeRoom.isBlank()) "Sin sala conectada" else "Sala $activeRoom", color = Ink, fontWeight = FontWeight.Bold); Text("${peers.size} conectado(s) · Wi‑Fi/Bluetooth", color = Muted, fontSize = 12.sp) }
                                TextButton(onClick = { currentTab = "Sala" }) { Text("Conectar") }
                            }
                            HorizontalDivider()
                            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                items(lines) { line -> Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.mine) Arrangement.End else Arrangement.Start) {
                                    Column(Modifier.widthIn(max = 290.dp).background(if (line.mine) Lilac else Color.White, RoundedCornerShape(18.dp)).padding(12.dp)) {
                                        if (!line.mine) Text(line.sender, color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(line.text, color = Ink)
                                        line.imageUri?.let { Image(rememberAsyncImagePainter(it), "Foto compartida", Modifier.sizeIn(maxWidth = 240.dp, maxHeight = 240.dp)) }
                                    }
                                } }
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(draft, { draft = it }, Modifier.weight(1f), placeholder = { Text("Escribe un mensaje") }, shape = RoundedCornerShape(22.dp), singleLine = true)
                                IconButton(onClick = { photoPicker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, "Enviar foto", tint = Purple) }
                                FilledIconButton(onClick = { if (draft.isNotBlank()) { nearby.sendText(name, draft); draft = "" } }) { Icon(Icons.Default.Send, "Enviar") }
                            }
                        }
                        "Sala" -> RoomScreen(name, roomCode, { roomCode = it }, joinCode, { joinCode = it }, activeRoom, peers.size,
                            onCreate = { code -> askPermissions { nearby.host(code, name); scope.launch { snack.showSnackbar("Buscando teléfonos cercanos para la sala $code") } } },
                            onJoin = { code -> askPermissions { nearby.join(code, name); scope.launch { snack.showSnackbar("Buscando la sala $code cerca de ti") } } },
                            onStop = { nearby.stop(); scope.launch { snack.showSnackbar("Desconectado") } }, modifier = Modifier.weight(1f))
                        else -> Column(Modifier.weight(1f).fillMaxWidth().padding(18.dp)) {
                            val winner = remember(tic) { ticWinner(tic) }
                            LaunchedEffect(remoteGame) { if (remoteGame.size == 10) { tic = remoteGame.take(9); ticTurn = remoteGame[9] } }
                            Text("Tres en raya", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text(if (winner.isNotBlank()) "Ganó $winner" else "Tu ficha: $gamePlayer · turno: $ticTurn", color = Purple, fontWeight = FontWeight.Bold)
                            Text("Solo juega en tu turno. Crear sala = X; unirse = O.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            for (r in 0..2) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { for (c in 0..2) { val i = r * 3 + c
                                OutlinedButton(enabled = ticTurn == gamePlayer && winner.isBlank() && tic[i].isBlank(), onClick = { if (tic[i].isBlank()) { tic = tic.toMutableList().also { it[i] = gamePlayer }; ticTurn = if (gamePlayer == "X") "O" else "X"; nearby.sendGameBoard(tic, ticTurn) } }, modifier = Modifier.weight(1f).height(80.dp), shape = RoundedCornerShape(16.dp)) { Text(tic[i], fontSize = 30.sp, color = Purple, fontWeight = FontWeight.Bold) }
                            } }
                            TextButton(onClick = { tic = List(9) { "" }; ticTurn = "X"; nearby.sendGameBoard(tic, ticTurn) }) { Text("Reiniciar partida") }
                        }
                    }
                    if (pending.isNotEmpty()) AlertDialog(onDismissRequest = { nearby.rejectPending() }, title = { Text("Solicitud de conexión") }, text = { Text("${pending.first().second} quiere entrar a la sala. ¿Aceptas?") }, confirmButton = { TextButton(onClick = { nearby.acceptPending() }) { Text("Aceptar") } }, dismissButton = { TextButton(onClick = { nearby.rejectPending() }) { Text("Rechazar") } })
                }
            }
        }
    }
}

private fun ticWinner(b: List<String>): String {
    if (b.size != 9) return ""
    val lines = listOf(listOf(0,1,2), listOf(3,4,5), listOf(6,7,8), listOf(0,3,6), listOf(1,4,7), listOf(2,5,8), listOf(0,4,8), listOf(2,4,6))
    return lines.firstNotNullOfOrNull { line -> b[line[0]].takeIf { it.isNotBlank() && line.all { i -> b[i] == it } } } ?: ""
}

@Composable private fun ProfileScreen(name: String, setName: (String) -> Unit, birthday: String, setBirthday: (String) -> Unit, photo: String, choosePhoto: () -> Unit, save: () -> Unit, padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("CHIP ENVÍA", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp)); Text("Tu espacio para\nconectar cerca.", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(10.dp)); Text("Crea tu perfil. La fecha de nacimiento se queda guardada en este teléfono.", color = Muted)
        Spacer(Modifier.height(24.dp)); Row(verticalAlignment = Alignment.CenterVertically) { if (photo.isNotBlank()) Image(rememberAsyncImagePainter(photo), "Foto", Modifier.size(58.dp)) else Icon(Icons.Default.Person, null, tint = Purple, modifier = Modifier.size(58.dp)); TextButton(onClick = choosePhoto) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(6.dp)); Text(if (photo.isBlank()) "Añadir foto" else "Cambiar foto") } }
        Spacer(Modifier.height(12.dp)); OutlinedTextField(name, setName, Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp)); OutlinedTextField(birthday, setBirthday, Modifier.fillMaxWidth(), label = { Text("Fecha de nacimiento (opcional)") }, placeholder = { Text("DD/MM/AAAA") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(18.dp)); Button(onClick = save, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Crear mi perfil") }
        Spacer(Modifier.height(12.dp)); Text("Se generará un ID para compartir. No pedimos documento.", color = Muted, fontSize = 12.sp)
    }
}

@Composable private fun TopBar(title: String, back: () -> Unit) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Atrás") }; Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink) } }

@Composable private fun RoomScreen(name: String, roomCode: String, setRoom: (String) -> Unit, joinCode: String, setJoin: (String) -> Unit, active: String, count: Int, onCreate: (String) -> Unit, onJoin: (String) -> Unit, onStop: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Salas cercanas", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Los teléfonos deben estar cerca. Crea o únete con el mismo código; cada conexión necesita aprobación.", color = Muted)
        Spacer(Modifier.height(14.dp))
        if (active.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = Lilac)) { Column(Modifier.fillMaxWidth().padding(14.dp)) { Text("Sala $active · $count conectado(s)", fontWeight = FontWeight.Bold, color = Ink); TextButton(onClick = onStop) { Text("Cerrar conexión") } } }
        Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Crear una sala", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Comparte el código o QR.", color = Muted, fontSize = 13.sp)
            OutlinedTextField(roomCode, setRoom, Modifier.fillMaxWidth(), label = { Text("Código de sala") }, singleLine = true)
            Button(onClick = { val code = roomCode.ifBlank { (100000..999999).random().toString() }; setRoom(code); onCreate(code) }, Modifier.fillMaxWidth()) { Text("Crear y anunciar sala") }
            if (roomCode.isNotBlank()) { Box(Modifier.fillMaxWidth(), Alignment.Center) { QrImage("chipenvia://sala/$roomCode", Modifier.size(170.dp)) }; Text("Código: $roomCode", Modifier.align(Alignment.CenterHorizontally), color = Purple, fontWeight = FontWeight.Bold) }
        } }
        Spacer(Modifier.height(10.dp))
        Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Unirse con código", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            OutlinedTextField(joinCode, setJoin, Modifier.fillMaxWidth(), label = { Text("Código compartido") }, singleLine = true)
            OutlinedButton(onClick = { if (joinCode.isNotBlank()) onJoin(joinCode.trim().uppercase()) }, Modifier.fillMaxWidth()) { Text("Buscar sala cercana") }
        } }
        Spacer(Modifier.height(10.dp)); Text("Perfil: $name", color = Muted, fontSize = 12.sp)
    }
}

@Composable private fun QrImage(content: String, modifier: Modifier = Modifier) {
    val bitmap = remember(content) { makeQr(content) }
    if (bitmap != null) Image(bitmap.asImageBitmap(), "Código QR", modifier)
}
private fun makeQr(text: String): Bitmap? = try {
    val m: BitMatrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 420, 420)
    Bitmap.createBitmap(420, 420, Bitmap.Config.RGB_565).also { b -> for (x in 0 until 420) for (y in 0 until 420) b.setPixel(x, y, if (m[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE) }
} catch (_: Exception) { null }
