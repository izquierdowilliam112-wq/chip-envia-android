package com.chipenvia.app

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Local-only transport. Every connected member advertises and discovers so cluster members can relay messages. */
class NearbyChat(context: Context) {
    private val appContext = context.applicationContext
    private val client = Nearby.getConnectionsClient(appContext)
    private val serviceId = "com.chipenvia.app.localchat"
    private val strategy = Strategy.P2P_CLUSTER
    private val connected = ConcurrentHashMap.newKeySet<String>()
    private val _messages = MutableStateFlow<List<ChatLine>>(emptyList())
    val messages: StateFlow<List<ChatLine>> = _messages
    private val _peers = MutableStateFlow<List<String>>(emptyList())
    val peers: StateFlow<List<String>> = _peers
    private val _pending = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val pending: StateFlow<List<Pair<String, String>>> = _pending
    private val _room = MutableStateFlow("")
    private val _gameBoard = MutableStateFlow<List<String>>(emptyList())
    val gameBoard: StateFlow<List<String>> = _gameBoard
    private val _gamePlayer = MutableStateFlow("X")
    val gamePlayer: StateFlow<String> = _gamePlayer
    val room: StateFlow<String> = _room
    private val endpointNames = ConcurrentHashMap<String, String>()
    private val requested = ConcurrentHashMap.newKeySet<String>()
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val receivedFiles = ConcurrentHashMap<Long, Pair<String, String>>()
    private val deviceToken = UUID.randomUUID().toString().take(6)
    @Volatile private var localName = "Invitado"

    private fun relay(raw: String, exceptEndpoint: String? = null) {
        val recipients = connected.filter { it != exceptEndpoint }
        if (recipients.isNotEmpty()) client.sendPayload(recipients, Payload.fromBytes(raw.toByteArray(Charsets.UTF_8)))
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val raw = payload.asBytes()?.toString(Charsets.UTF_8) ?: return
                    val packet = runCatching { JSONObject(raw) }.getOrNull() ?: return
                    val id = packet.optString("id")
                    if (id.isBlank() || !seen.add(id)) return
                    val ttl = packet.optInt("ttl", 0)
                    when (packet.optString("kind")) {
                        "message" -> {
                            val sender = packet.optString("sender", "Contacto").take(40)
                            val body = packet.optString("body").take(8000)
                            _messages.value = (_messages.value + ChatLine(sender, body, false)).takeLast(500)
                            ConnectionService.notifyMessage(appContext, sender, body)
                        }
                        "game" -> {
                            val board = packet.optString("board")
                            val turn = packet.optString("turn")
                            if (board.length == 9 && board.all { it == 'X' || it == 'O' || it == '-' } && turn in listOf("X", "O")) {
                                val xCount = board.count { it == 'X' }; val oCount = board.count { it == 'O' }
                                val expectedTurn = if (xCount == oCount) "X" else "O"
                                if (xCount in oCount..(oCount + 1) && turn == expectedTurn) _gameBoard.value = board.map { if (it == '-') "" else it.toString() } + turn
                            }
                        }
                    }
                    if (ttl > 0) relay(packet.put("ttl", ttl - 1).toString(), endpointId)
                }
                Payload.Type.FILE -> {
                    val f = payload.asFile()?.asJavaFile() ?: return
                    receivedFiles[payload.id] = (endpointNames[endpointId] ?: "Contacto") to f.absolutePath
                }
                else -> Unit
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                val received = receivedFiles.remove(update.payloadId) ?: return
                val source = File(received.second)
                val dir = File(appContext.filesDir, "received-photos").apply { mkdirs() }
                val target = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                runCatching { source.copyTo(target, overwrite = true) }.onSuccess {
                    _messages.value = (_messages.value + ChatLine(received.first, "📷 Foto recibida", false, target.toUriString())).takeLast(500)
                }
            }
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            endpointNames[endpointId] = parseName(info.endpointName)
            _pending.value = (_pending.value.filterNot { it.first == endpointId } + (endpointId to endpointNames[endpointId]!!))
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            _pending.value = _pending.value.filterNot { it.first == endpointId }
            if (result.status.isSuccess) {
                connected.add(endpointId)
                _peers.value = connected.map { endpointNames[it] ?: "Teléfono conectado" }
                _messages.value = (_messages.value + ChatLine("Chip Envía", "${endpointNames[endpointId] ?: "Alguien"} se conectó", false)).takeLast(500)
            } else { connected.remove(endpointId); requested.remove(endpointId); _peers.value = connected.map { endpointNames[it] ?: "Teléfono conectado" } }
        }
        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId); requested.remove(endpointId)
            _peers.value = connected.map { endpointNames[it] ?: "Teléfono conectado" }
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val fields = info.endpointName.split(':', limit = 4)
            if (fields.size < 4 || fields[0] != "CHIP" || fields[1] != _room.value || endpointId in connected) return
            endpointNames[endpointId] = fields[2]
            if (requested.add(endpointId)) client.requestConnection(localName, endpointId, lifecycle)
        }
        override fun onEndpointLost(endpointId: String) { }
    }

    fun host(code: String, name: String) = start(code, name, "X")
    fun join(code: String, name: String) = start(code, name, "O")
    private fun parseName(endpointName: String) = endpointName.split(':', limit = 4).getOrNull(2)?.ifBlank { "Invitado" } ?: "Invitado"

    /** Permissions must be granted by the activity before calling start. */
    private fun start(code: String, name: String, player: String) {
        stop()
        _gamePlayer.value = player
        _gameBoard.value = List(9) { "" } + "X"
        val cleanCode = code.filter { it.isLetterOrDigit() }.uppercase().take(12)
        if (cleanCode.isBlank()) return
        localName = name.ifBlank { "Invitado" }.replace(':', ' ').take(25)
        _room.value = cleanCode
        val endpointName = "CHIP:$cleanCode:$localName:$deviceToken"
        ConnectionService.start(appContext)
        // All room members advertise and discover: P2P_CLUSTER can connect multiple devices;
        // the bounded packet TTL and message IDs prevent relay loops and duplicate display.
        client.startAdvertising(endpointName, serviceId, lifecycle, AdvertisingOptions.Builder().setStrategy(strategy).build())
        client.startDiscovery(serviceId, discovery, DiscoveryOptions.Builder().setStrategy(strategy).build())
    }

    fun acceptPending() {
        val id = _pending.value.firstOrNull()?.first ?: return
        client.acceptConnection(id, payloadCallback)
    }
    fun rejectPending() {
        val id = _pending.value.firstOrNull()?.first ?: return
        client.rejectConnection(id)
        _pending.value = _pending.value.filterNot { it.first == id }
    }
    fun sendText(sender: String, text: String) {
        val body = text.trim().take(8000)
        if (connected.isEmpty() || body.isEmpty()) return
        val safeSender = sender.replace('\n', ' ').take(40)
        val id = UUID.randomUUID().toString(); seen.add(id)
        val packet = JSONObject().put("kind", "message").put("id", id).put("sender", safeSender).put("body", body).put("ttl", 8).toString()
        relay(packet)
        _messages.value = (_messages.value + ChatLine(safeSender, body, true)).takeLast(500)
    }
    fun sendGameBoard(board: List<String>, next: String) {
        if (connected.isEmpty() || board.size != 9 || board.any { it !in listOf("", "X", "O") } || next !in listOf("X", "O")) return
        val id = UUID.randomUUID().toString(); seen.add(id)
        relay(JSONObject().put("kind", "game").put("id", id).put("board", board.joinToString("") { it.ifBlank { "-" } }).put("turn", next).put("ttl", 8).toString())
    }
    fun sendPhoto(file: File, sender: String) {
        if (connected.isEmpty() || !file.exists() || file.length() > 15L * 1024 * 1024) return
        client.sendPayload(connected.toList(), Payload.fromFile(file))
        _messages.value = (_messages.value + ChatLine(sender, "📷 Foto enviada: ${file.name}", true, file.toUriString())).takeLast(500)
    }
    fun stop() {
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
        ConnectionService.stop(appContext)
        connected.clear(); requested.clear(); endpointNames.clear(); seen.clear(); receivedFiles.clear()
        _pending.value = emptyList(); _peers.value = emptyList(); _room.value = ""
    }
}

private fun File.toUriString() = android.net.Uri.fromFile(this).toString()
